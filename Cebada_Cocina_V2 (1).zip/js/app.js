const WHATSAPP = "5491122897108";

const products = [
  // LAMINADOS
  {id:"medialunas-xl",cat:"laminados",name:"Medialunas XL",desc:"Docena de medialunas laminadas.",price:18000,unit:"x12",img:"laminados"},
  {id:"medialunas-rellenas",cat:"laminados",name:"Medialunas rellenas",desc:"Pastelera, dulce de leche o membrillo.",price:18000,unit:"x12",altPrice:9500,altUnit:"x6",img:"laminados"},
  {id:"facturas",cat:"laminados",name:"Facturas",desc:"Clásicas, pastelera, membrillo o dulce de leche.",price:18000,unit:"x12",altPrice:9500,altUnit:"x6",img:"laminados"},
  {id:"medialunas-grasa",cat:"laminados",name:"Medialunas de grasa",desc:"Laminadas en grasa.",price:15000,unit:"x12",img:"laminados"},
  {id:"croissant",cat:"laminados",name:"Croissant",desc:"Croissant individual.",price:2500,unit:"x1",img:"laminados"},

  // COOKIES
  {id:"cookie-choco-nuez",cat:"cookies",name:"Cookie choco nuez",desc:"Chocolate y nuez.",price:14000,unit:"x12 mini o x6 XL",img:"cookies"},
  {id:"cookie-choco-mani",cat:"cookies",name:"Cookie choco maní",desc:"Chocolate y maní.",price:14000,unit:"x12 mini o x6 XL",img:"cookies"},

  // ALFAJORES
  {id:"alfajor-chocolate",cat:"alfajores",name:"Alfajores de chocolate",desc:"Caja de alfajores de chocolate.",price:16000,unit:"x6",img:"alfajores"},
  {id:"alfajor-maicena",cat:"alfajores",name:"Alfajores de maicena",desc:"Caja de alfajores de maicena.",price:14000,unit:"x6",img:"alfajores"},
  {id:"mini-alfajores",cat:"alfajores",name:"Mini alfajores surtidos",desc:"Surtido para compartir.",price:12000,unit:"x12",img:"alfajores"},

  // PARA COMPARTIR
  {id:"cuadrados",cat:"compartir",name:"Cuadrados",desc:"Lemonie, pastafrolla, coco y DDL o brownie. Sujeto a stock.",price:16000,unit:"x12",img:"compartir"},
  {id:"bandeja-surtida",cat:"compartir",name:"Bandeja surtida",desc:"Cuadrados, alfajorcitos y mini cookies. Sujeto a stock.",price:24000,unit:"x24",img:"compartir"},
  {id:"pepas",cat:"compartir",name:"Pepas",desc:"Pepas de membrillo.",price:5000,unit:"1/4 kg",img:"compartir"},
  {id:"mini-rolls",cat:"compartir",name:"Mini rolls de canela",desc:"Mini rolls de canela.",price:9000,unit:"x12",img:"compartir"},
  {id:"granola",cat:"compartir",name:"Granola",desc:"Nuez, castaña, avena, maní, pasas, naranja, canela y semillas. Apto vegano.",price:9500,unit:"350 g",img:"granola"},

  // SALADO
  {id:"chipacitos",cat:"salado",name:"Chipacitos",desc:"Chipacitos de producción propia.",price:15000,unit:"x15",img:"salado"},
  {id:"focaccia",cat:"salado",name:"Focaccia",desc:"Cebolla, tomate o clásica.",price:7500,unit:"500 g",img:"salado"},
  {id:"prepizzas",cat:"salado",name:"Prepizzas",desc:"Larga fermentación.",price:8000,unit:"x2",img:"salado"},
  {id:"laminado-pesto",cat:"salado",name:"Laminado pesto & tomate",desc:"Laminado salado con pesto y tomate.",price:14000,unit:"x5",img:"salado"},

  // PANES
  {id:"pan-semi-integral",cat:"panes",name:"Pan semi integral con semillas",desc:"Pan semi integral con semillas.",price:8000,unit:"x1",img:"salado"},
  {id:"pan-centeno",cat:"panes",name:"Pan de centeno",desc:"Pan de centeno.",price:9500,unit:"x1",img:"salado"},
];

const categoryData = {
  laminados:{title:"Laminados",intro:"Medialunas, facturas y croissant para resolver el antojo.",anchor:"laminados"},
  cookies:{title:"Cookies",intro:"Cookies para merendar, regalar o no compartir.",anchor:"cookies"},
  alfajores:{title:"Alfajores",intro:"Clásicos y mini surtidos.",anchor:"alfajores"},
  compartir:{title:"Para compartir",intro:"Packs pensados para la merienda y las juntadas.",anchor:"compartir"},
  salado:{title:"Salado",intro:"Opciones para picadas, juntadas y antojos salados.",anchor:"salado"},
  panes:{title:"Panes",intro:"Panes de producción propia.",anchor:"panes"}
};

const imageMap = {
  laminados:"images/categories/laminados.jpg",
  cookies:"images/categories/cookies.jpg",
  alfajores:"images/categories/alfajores.jpg",
  compartir:"images/categories/compartir.jpg",
  salado:"images/categories/salado.jpg",
  panes:"images/categories/salado.jpg",
  granola:"images/categories/granola.jpg"
};

const cart = {};

const money = n => new Intl.NumberFormat("es-AR").format(n);

function renderProducts(){
  const root = document.getElementById("productSections");
  root.innerHTML = "";

  Object.keys(categoryData).forEach(cat=>{
    const info = categoryData[cat];
    const section = document.createElement("section");
    section.className = "product-section";
    section.id = info.anchor;

    const head = document.createElement("div");
    head.className = "product-section-head";
    head.innerHTML = `<div><p class="eyebrow">CEBADA</p><h2>${info.title}</h2></div><p>${info.intro}</p>`;
    section.appendChild(head);

    const grid = document.createElement("div");
    grid.className = "product-grid";

    products.filter(p=>p.cat===cat).forEach(p=>{
      const card = document.createElement("article");
      card.className = "product-card";
      const qty = cart[p.id] || 0;
      card.innerHTML = `
        <div class="product-photo" style="background-image:url('${imageMap[p.img] || imageMap[cat]}')"></div>
        <div class="product-info">
          <h3>${p.name}</h3>
          <div class="product-desc">${p.desc}</div>
          <div class="product-bottom">
            <div class="price">$${money(p.price)} <span class="unit">${p.unit}${p.altPrice ? ` · $${money(p.altPrice)} ${p.altUnit}` : ""}</span></div>
            <div class="qty">
              <button type="button" onclick="changeQty('${p.id}',-1)">−</button>
              <span id="qty-${p.id}">${qty}</span>
              <button type="button" onclick="changeQty('${p.id}',1)">+</button>
            </div>
          </div>
        </div>`;
      grid.appendChild(card);
    });

    section.appendChild(grid);
    root.appendChild(section);
  });
}

function changeQty(id, delta){
  const product = products.find(p=>p.id===id);
  if(!product) return;
  cart[id] = Math.max(0,(cart[id]||0)+delta);
  if(cart[id]===0) delete cart[id];
  document.getElementById(`qty-${id}`).textContent = cart[id] || 0;
  updateCart();
}

function cartTotal(){
  return Object.entries(cart).reduce((sum,[id,qty])=>{
    const p=products.find(x=>x.id===id);
    return sum + (p.price*qty);
  },0);
}

function cartCount(){
  return Object.values(cart).reduce((a,b)=>a+b,0);
}

function updateCart(){
  document.getElementById("cartCount").textContent = cartCount();
  document.getElementById("cartTotal").textContent = money(cartTotal());

  const root=document.getElementById("cartItems");
  const empty=document.getElementById("cartEmpty");
  root.innerHTML="";

  Object.entries(cart).forEach(([id,qty])=>{
    const p=products.find(x=>x.id===id);
    const row=document.createElement("div");
    row.className="cart-line";
    row.innerHTML=`
      <div><strong>${p.name}</strong><small>${qty} × $${money(p.price)} · ${p.unit}</small></div>
      <div class="cart-line-controls">
        <button onclick="changeQty('${id}',-1)">−</button>
        <strong>${qty}</strong>
        <button onclick="changeQty('${id}',1)">+</button>
      </div>`;
    root.appendChild(row);
  });

  empty.hidden=cartCount()>0;
  updateShippingProgress();
}

function selectedZoneMin(){
  const zone=document.getElementById("zona");
  return zone ? Number(zone.value) : 0;
}

function updateShippingProgress(){
  const box=document.getElementById("cartProgress");
  const text=document.getElementById("shippingProgressText");
  const bar=document.getElementById("progressBar");
  const total=cartTotal();
  const min=selectedZoneMin();

  if(!min){
    box.hidden=true;
    return;
  }

  box.hidden=false;
  const pct=Math.min(100,(total/min)*100);
  bar.style.width=`${pct}%`;

  if(total>=min){
    text.textContent="🎉 ¡Listo! Tenés envío gratis.";
  }else{
    text.textContent=`Te faltan $${money(min-total)} para tu envío gratis.`;
  }
}

function openCart(){
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("cartOverlay").classList.add("open");
}
function closeCart(){
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("cartOverlay").classList.remove("open");
}

function openCheckout(){
  if(cartCount()===0){
    alert("Agregá al menos un producto al pedido.");
    return;
  }
  renderCheckoutSummary();
  closeCart();
  document.getElementById("checkoutOverlay").classList.add("open");
  const d=new Date(Date.now()+24*60*60*1000);
  const local=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10);
  document.getElementById("fecha").min=local;
}
function closeCheckout(){
  document.getElementById("checkoutOverlay").classList.remove("open");
}

function renderCheckoutSummary(){
  const root=document.getElementById("checkoutSummary");
  root.innerHTML=Object.entries(cart).map(([id,qty])=>{
    const p=products.find(x=>x.id===id);
    return `<div class="summary-row"><span>${p.name} × ${qty}</span><strong>$${money(p.price*qty)}</strong></div>`;
  }).join("") + `<hr><div class="summary-row"><strong>Total</strong><strong>$${money(cartTotal())}</strong></div>`;
}

function updateCheckoutShipping(){
  const mode=document.getElementById("modalidad").value;
  const box=document.getElementById("shippingBox");
  box.hidden=mode!=="envio";
  updateShippingProgress();

  if(mode!=="envio") return;

  const min=selectedZoneMin();
  const total=cartTotal();
  const msg=document.getElementById("shippingMessage");
  if(!min){
    msg.textContent="Seleccioná tu zona para calcular el mínimo de envío gratis.";
    return;
  }
  msg.textContent = total>=min
    ? "🎉 ¡Tu pedido tiene envío gratis!"
    : `Te faltan $${money(min-total)} para tu envío gratis. Si querés enviarlo igual, podemos coordinar Uber a cargo del cliente.`;
}

function validateDate(){
  const value=document.getElementById("fecha").value;
  if(!value) return false;
  const selected=new Date(value+"T23:59:59");
  const min=new Date(Date.now()+24*60*60*1000);
  return selected>=min;
}

function openSpecialWhatsApp(type){
  const msg = type==="mayorista"
    ? "Hola Cebada! Soy comercio y quiero consultar precios mayoristas y condiciones para reventa."
    : "Hola Cebada! Quiero consultar por tortas, catering o un evento.";
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`,"_blank");
}

function sendOrder(){
  if(cartCount()===0){alert("Agregá al menos un producto.");return;}
  const nombre=document.getElementById("nombre").value.trim();
  const telefono=document.getElementById("telefono").value.trim();
  const fecha=document.getElementById("fecha").value;
  const modalidad=document.getElementById("modalidad").value;
  const pago=document.getElementById("pago").value;

  if(!nombre||!telefono||!fecha||!modalidad||!pago){
    alert("Completá nombre, teléfono, fecha, modalidad y forma de pago.");
    return;
  }
  if(!validateDate()){
    alert("La fecha debe tener mínimo 24 horas de anticipación.");
    return;
  }

  let envioText="Retiro por Cebada";
  if(modalidad==="envio"){
    const zone=document.getElementById("zona");
    const direccion=document.getElementById("direccion").value.trim();
    if(!zone.value||!direccion){
      alert("Completá zona y dirección de envío.");
      return;
    }
    const min=Number(zone.value);
    envioText=`Envío — ${zone.selectedOptions[0].text}`;
    if(cartTotal()<min) envioText += " — por debajo del mínimo: coordinar Uber a cargo del cliente";
    else envioText += " — ENVÍO GRATIS";
    envioText += ` — ${direccion}`;
  }

  const items=Object.entries(cart).map(([id,qty])=>{
    const p=products.find(x=>x.id===id);
    return `• ${p.name} × ${qty} — $${money(p.price*qty)}`;
  }).join("\n");

  const msg=`Hola Cebada! Quiero hacer este pedido:

${items}

TOTAL: $${money(cartTotal())}

Nombre: ${nombre}
Teléfono: ${telefono}
Fecha: ${fecha}
Modalidad: ${envioText}
Forma de pago: ${pago}

Pedido realizado desde la web.`;

  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`,"_blank");
}

document.getElementById("openCart").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
document.getElementById("cartOverlay").addEventListener("click",closeCart);
document.getElementById("goCheckout").addEventListener("click",openCheckout);
document.getElementById("closeCheckout").addEventListener("click",closeCheckout);
document.getElementById("modalidad").addEventListener("change",updateCheckoutShipping);
document.getElementById("zona").addEventListener("change",updateCheckoutShipping);
document.getElementById("sendOrder").addEventListener("click",sendOrder);

renderProducts();
updateCart();
