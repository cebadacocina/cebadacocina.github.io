# Cebada Cocina — V2

Primera versión de la tienda visual basada en el catálogo minorista de octubre.

Incluye:
- Carrito real con + / -
- Catálogo por categorías
- Mínimo 24 h de anticipación
- Retiro o envío
- Mínimos de envío gratis por zona
- Mensaje dinámico "Te faltan $X para tu envío gratis"
- Uber si no se alcanza el mínimo
- Checkout por WhatsApp
- Catering / Eventos / Tortas por WhatsApp
- Consulta mayorista por WhatsApp
- Fotos provisionales extraídas del catálogo de octubre

Nota:
Los productos y precios cargados corresponden al catálogo de octubre. No se agregaron productos que no tengan precio en ese catálogo.
